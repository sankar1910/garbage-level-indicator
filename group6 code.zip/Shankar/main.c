//FSM Program for Odd 1's detector
//Input Switch - PF4
//Output LED - PF2

#define TIMER1_CFG_R            (*((volatile unsigned long *)0x40031000))
#define TIMER1_TAMR_R           (*((volatile unsigned long *)0x40031004))
#define TIMER1_TBMR_R           (*((volatile unsigned long *)0x40031008))
#define TIMER1_CTL_R            (*((volatile unsigned long *)0x4003100C))
#define TIMER1_SYNC_R           (*((volatile unsigned long *)0x40031010))
#define TIMER1_IMR_R            (*((volatile unsigned long *)0x40031018))
#define TIMER1_RIS_R            (*((volatile unsigned long *)0x4003101C))
#define TIMER1_MIS_R            (*((volatile unsigned long *)0x40031020))
#define TIMER1_ICR_R            (*((volatile unsigned long *)0x40031024))
#define TIMER1_TAILR_R          (*((volatile unsigned long *)0x40031028))
#define TIMER1_TBILR_R          (*((volatile unsigned long *)0x4003102C))
#define TIMER1_TAMATCHR_R       (*((volatile unsigned long *)0x40031030))
#define TIMER1_TBMATCHR_R       (*((volatile unsigned long *)0x40031034))
#define TIMER1_TAPR_R           (*((volatile unsigned long *)0x40031038))
#define TIMER1_TBPR_R           (*((volatile unsigned long *)0x4003103C))
#define TIMER1_TAPMR_R          (*((volatile unsigned long *)0x40031040))
#define TIMER1_TBPMR_R          (*((volatile unsigned long *)0x40031044))
#define TIMER1_TAR_R            (*((volatile unsigned long *)0x40031048))
#define TIMER1_TBR_R            (*((volatile unsigned long *)0x4003104C))
#define TIMER1_TAV_R            (*((volatile unsigned long *)0x40031050))
#define TIMER1_TBV_R            (*((volatile unsigned long *)0x40031054))
#define TIMER1_RTCPD_R          (*((volatile unsigned long *)0x40031058))
#define TIMER1_TAPS_R           (*((volatile unsigned long *)0x4003105C))
#define TIMER1_TBPS_R           (*((volatile unsigned long *)0x40031060))
#define TIMER1_TAPV_R           (*((volatile unsigned long *)0x40031064))
#define TIMER1_TBPV_R           (*((volatile unsigned long *)0x40031068))
#define TIMER1_PP_R             (*((volatile unsigned long *)0x40031FC0))
#define SYSCTL_RCGCTIMER_R      (*((volatile unsigned long *)0x400FE604))
#define SYSCTL_RCGCGPIO_R       (*((volatile unsigned long *)0x400FE608))

#define TIMER2_CFG_R            (*((volatile unsigned long *)0x40032000))
#define TIMER2_TAMR_R           (*((volatile unsigned long *)0x40032004))
#define TIMER2_TBMR_R           (*((volatile unsigned long *)0x40032008))
#define TIMER2_CTL_R            (*((volatile unsigned long *)0x4003200C))
#define TIMER2_SYNC_R           (*((volatile unsigned long *)0x40032010))
#define TIMER2_IMR_R            (*((volatile unsigned long *)0x40032018))
#define TIMER2_RIS_R            (*((volatile unsigned long *)0x4003201C))
#define TIMER2_MIS_R            (*((volatile unsigned long *)0x40032020))
#define TIMER2_ICR_R            (*((volatile unsigned long *)0x40032024))
#define TIMER2_TAILR_R          (*((volatile unsigned long *)0x40032028))
#define TIMER2_TBILR_R          (*((volatile unsigned long *)0x4003202C))
#define TIMER2_TAMATCHR_R       (*((volatile unsigned long *)0x40032030))
#define TIMER2_TBMATCHR_R       (*((volatile unsigned long *)0x40032034))
#define TIMER2_TAPR_R           (*((volatile unsigned long *)0x40032038))
#define TIMER2_TBPR_R           (*((volatile unsigned long *)0x4003203C))
#define TIMER2_TAPMR_R          (*((volatile unsigned long *)0x40032040))
#define TIMER2_TBPMR_R          (*((volatile unsigned long *)0x40032044))
#define TIMER2_TAR_R            (*((volatile unsigned long *)0x40032048))
#define TIMER2_TBR_R            (*((volatile unsigned long *)0x4003204C))
#define TIMER2_TAV_R            (*((volatile unsigned long *)0x40032050))
#define TIMER2_TBV_R            (*((volatile unsigned long *)0x40032054))
#define TIMER2_RTCPD_R          (*((volatile unsigned long *)0x40032058))
#define TIMER2_TAPS_R           (*((volatile unsigned long *)0x4003205C))
#define TIMER2_TBPS_R           (*((volatile unsigned long *)0x40032060))
#define TIMER2_TAPV_R           (*((volatile unsigned long *)0x40032064))
#define TIMER2_TBPV_R           (*((volatile unsigned long *)0x40032068))
#define TIMER2_PP_R             (*((volatile unsigned long *)0x40032FC0))
	
#define GPIO_PORTF_DATA_R       (*((volatile unsigned long *)0x400253FC))
#define GPIO_PORTF_DIR_R        (*((volatile unsigned long *)0x40025400))
#define GPIO_PORTF_AFSEL_R      (*((volatile unsigned long *)0x40025420))
#define GPIO_PORTF_PUR_R        (*((volatile unsigned long *)0x40025510))
#define GPIO_PORTF_DEN_R        (*((volatile unsigned long *)0x4002551C))
#define GPIO_PORTF_LOCK_R       (*((volatile unsigned long *)0x40025520))
#define GPIO_PORTF_CR_R         (*((volatile unsigned long *)0x40025524))
#define GPIO_PORTF_AMSEL_R      (*((volatile unsigned long *)0x40025528))
#define GPIO_PORTF_PCTL_R       (*((volatile unsigned long *)0x4002552C))
#define SYSCTL_RCGC2_R          (*((volatile unsigned long *)0x400FE108))
	
#define GPIO_PORTA_DATA_R       (*((volatile unsigned long *)0x400043FC))
#define GPIO_PORTA_DIR_R        (*((volatile unsigned long *)0x40004400))
#define GPIO_PORTA_AFSEL_R      (*((volatile unsigned long *)0x40004420))
#define GPIO_PORTA_PUR_R        (*((volatile unsigned long *)0x40004510))
#define GPIO_PORTA_PDR_R        (*((volatile unsigned long *)0x40004514))
#define GPIO_PORTA_DEN_R        (*((volatile unsigned long *)0x4000451C))
#define GPIO_PORTA_LOCK_R       (*((volatile unsigned long *)0x40004520))
#define GPIO_PORTA_CR_R         (*((volatile unsigned long *)0x40004524))
#define GPIO_PORTA_AMSEL_R      (*((volatile unsigned long *)0x40004528))
#define GPIO_PORTA_PCTL_R       (*((volatile unsigned long *)0x4000452C))

#define GPIO_PORTB_DATA_BITS_R  ((volatile unsigned long *)0x40005000)
#define GPIO_PORTB_DATA_R       (*((volatile unsigned long *)0x400053FC))
#define GPIO_PORTB_DIR_R        (*((volatile unsigned long *)0x40005400))
#define GPIO_PORTB_IS_R         (*((volatile unsigned long *)0x40005404))
#define GPIO_PORTB_IBE_R        (*((volatile unsigned long *)0x40005408))
#define GPIO_PORTB_IEV_R        (*((volatile unsigned long *)0x4000540C))
#define GPIO_PORTB_IM_R         (*((volatile unsigned long *)0x40005410))
#define GPIO_PORTB_RIS_R        (*((volatile unsigned long *)0x40005414))
#define GPIO_PORTB_MIS_R        (*((volatile unsigned long *)0x40005418))
#define GPIO_PORTB_ICR_R        (*((volatile unsigned long *)0x4000541C))
#define GPIO_PORTB_AFSEL_R      (*((volatile unsigned long *)0x40005420))
#define GPIO_PORTB_DR2R_R       (*((volatile unsigned long *)0x40005500))
#define GPIO_PORTB_DR4R_R       (*((volatile unsigned long *)0x40005504))
#define GPIO_PORTB_DR8R_R       (*((volatile unsigned long *)0x40005508))
#define GPIO_PORTB_ODR_R        (*((volatile unsigned long *)0x4000550C))
#define GPIO_PORTB_PUR_R        (*((volatile unsigned long *)0x40005510))
#define GPIO_PORTB_PDR_R        (*((volatile unsigned long *)0x40005514))
#define GPIO_PORTB_SLR_R        (*((volatile unsigned long *)0x40005518))
#define GPIO_PORTB_DEN_R        (*((volatile unsigned long *)0x4000551C))
#define GPIO_PORTB_LOCK_R       (*((volatile unsigned long *)0x40005520))
#define GPIO_PORTB_CR_R         (*((volatile unsigned long *)0x40005524))
#define GPIO_PORTB_AMSEL_R      (*((volatile unsigned long *)0x40005528))
#define GPIO_PORTB_PCTL_R       (*((volatile unsigned long *)0x4000552C))
#define GPIO_PORTB_ADCCTL_R     (*((volatile unsigned long *)0x40005530))
#define GPIO_PORTB_DMACTL_R     (*((volatile unsigned long *)0x40005534))
	
#include "SysTick.h"

const double _16MHz_1clock = 62.5e-9; /*Value of 1clock cycle in nanoseconds*/

const unsigned int  MULTIPLIER = 5882;
void Timer2_init(void)

{

SYSCTL_RCGCTIMER_R |=(0x04); 
	//GPIO_PORTF_DATA_R &= (~0x0E);
	//GPIO_PORTF_DATA_R |= (0x08);
	SYSCTL_RCGCGPIO_R |=(1U<<1); 
	
GPIO_PORTB_DATA_R &= (~0x01);//Echo PB0

GPIO_PORTB_DEN_R |=(0x01);//Echo

GPIO_PORTB_AFSEL_R |=(0x01);//Echo

GPIO_PORTB_PCTL_R &=~0x0000000F;

GPIO_PORTB_PCTL_R |= 0x00000007;

TIMER2_CTL_R &=~1;

TIMER2_CFG_R =4;

TIMER2_TAMR_R = 0x17;

TIMER2_CTL_R |=0x0C;

TIMER2_CTL_R |=1;

}

///*
void delay_Microsecond(unsigned int time)

{

int i;

SYSCTL_RCGCTIMER_R |=(1U<<1); TIMER1_CTL_R=0;

TIMER1_CFG_R=0x04;

TIMER1_TAMR_R=0x02;

TIMER1_TAILR_R= 16-1;

TIMER1_ICR_R =0x1;

TIMER1_CTL_R |=0x01;

for(i=0;i<time;i++) { while((TIMER1_RIS_R & 0x1)==0);

TIMER1_ICR_R = 0x1;

}

}
//*/
unsigned int highEdge, lowEdge, ddistance;
unsigned int measureD(void) {
//GPIO_PORTF_DATA_R &= (~0x0E);
	//GPIO_PORTF_DATA_R |= (0x0E);
	//SysTick_Wait10ms(100);
	
GPIO_PORTA_DATA_R &=(~0x04); //Trigger PA2

 delay_Microsecond(12);
	//SysTick_Wait(192);

GPIO_PORTA_DATA_R |=0x04; //Trigger

delay_Microsecond(12);
//SysTick_Wait(192);
GPIO_PORTA_DATA_R &=(~0x04);//Trigger

/*Capture firstEgde i.e. rising edge*/

TIMER2_ICR_R =4;

while((TIMER2_RIS_R &4)==0){}; //Wait till captured

highEdge = TIMER2_TAR_R;

/*Capture secondEdge i.e. falling edge */

TIMER2_ICR_R =4; //cleaer timer capture flag

while((TIMER2_RIS_R &4) ==0){};

lowEdge = TIMER2_TAR_R;

ddistance = lowEdge -highEdge;

ddistance = _16MHz_1clock *(double) MULTIPLIER *(double)ddistance;
//GPIO_PORTF_DATA_R &= (~0x0E);
	//GPIO_PORTF_DATA_R |= (0x06);
	//SysTick_Wait10ms(100);
return ddistance;

}


void PortA_Init(void){ volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0x00000001;     // Activate clock for Port A
  delay = SYSCTL_RCGC2_R;           // Allow time for clock to start
  GPIO_PORTA_AMSEL_R &= (~0x3C);        // Disable analog on PA2,PA3,PA4,PA5
  GPIO_PORTA_PCTL_R &= (~0x3C);   // PCTL GPIO on PA2,3,4,5
  //GPIO_PORTA_DIR_R &= (~0x38);        //   PA3,4,5 input
	GPIO_PORTA_DIR_R |= 0x3C;         //   PA2,3,4,5 output
  GPIO_PORTA_AFSEL_R &= (~0x3C);      // Disable alt funct on PA1,3,4,5
  GPIO_PORTA_DEN_R |= 0x3C;         // Enable digital I/O on PA1,3,4,5
}
/*
void PortB_Init(void){ volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0x00000002;     // Activate clock for Port B
  delay = SYSCTL_RCGC2_R;           // Allow time for clock to start
  GPIO_PORTB_AMSEL_R &= (~0xF9);    // Disable analog on PB0,3,4,5,6,7
  GPIO_PORTB_PCTL_R &= (~0xF8);     // PCTL GPIO on PB3,4,5,6,7
	GPIO_PORTB_DIR_R |= 0xF8;         // PB3,4,5,6,7 output
  GPIO_PORTB_AFSEL_R &= (~0xF8);    // Disable alt funct on PB3,4,5,6,7
  GPIO_PORTB_DEN_R |= 0xF8;         // Enable digital I/O on PB3,4,5,6,7
}

void PortF_Init(void){ volatile unsigned long delay;
  SYSCTL_RCGC2_R |= 0x00000020;     // Activate clock for Port F
  delay = SYSCTL_RCGC2_R;           // Allow time for clock to start
  GPIO_PORTF_AMSEL_R = 0x00;        // Disable analog on PF4 and PF2
  GPIO_PORTF_PCTL_R = 0x00000000;   // PCTL GPIO on PF4-0
  GPIO_PORTF_DIR_R &= ~0x10;        //   PF4 input
	GPIO_PORTF_DIR_R |= 0x0E;         //   PF2 output
  GPIO_PORTF_AFSEL_R &= ~0x1E;      // Disable alt funct on PF4 and PF2
  //GPIO_PORTF_PUR_R |= 0x10;         // Enable pull-up on PF4
  GPIO_PORTF_DEN_R |= 0x1E;         // Enable digital I/O on PF4 and PF2
}
*/
unsigned int dist=0;
// represents a State of the FSM 
struct State {
   unsigned long out;   // output for the state
   unsigned long wait;     // Time to wait when in this state
   unsigned int next[3]; // Next state array
};

//Shortcuts to refer to the various states in the FSM array
const unsigned int L1 = 0;
const unsigned int L2 = 1;
const unsigned int L3 = 2;

//The data structure that captures the FSM state transition graph

struct State Fsm[4] = { 
   {0x08,100,{L1,L2,L3}},
   {0x10,100,{L1,L2,L3}},
	 {0x20,100,{L1,L2,L3}}
}; 

void change(unsigned long X) {
	GPIO_PORTA_DATA_R &= ~0x38;
	GPIO_PORTA_DATA_R |= X;
}
	unsigned int input;
	unsigned int pState,cState;
int main(void) {
	PortA_Init();
	//PortB_Init();
	//PortF_Init();
	SysTick_Init();
	Timer2_init();
  //unsigned int input;
	//unsigned int pState;
	GPIO_PORTA_DATA_R &= (~0x38);
	GPIO_PORTA_DATA_R |= (0x38);
	SysTick_Wait10ms(100);

	cState = L1;
	pState = L3;
	while(1) {
		if(pState!=cState) {
			 change(Fsm[cState].out);
		}	
		SysTick_Wait10ms(Fsm[cState].wait);
		dist = measureD();
		pState = cState;
		if(dist<2) {
				input = 2;
		}
		else if(dist<5) {
			input = 1;
		}
		else {
			input = 0;
		}	
		//SysTick_Wait10ms(10);	
		cState = Fsm[cState].next[input]; 
	}
}	
